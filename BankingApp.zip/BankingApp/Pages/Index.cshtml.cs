﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BankingApp.Pages
{
    /// <summary>
    /// Page just has a short description and links to log in or Create a page.
    /// </summary>
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
